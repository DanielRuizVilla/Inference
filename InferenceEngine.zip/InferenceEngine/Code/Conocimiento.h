//
// Grado en Ingeniería Informática. 3º Curso
// Sistemas Inteligentes - Práctica 2
// Daniel Ruiz Villa - 77757166P
//

#ifndef PRACTICA2_CONOCIMIENTO_H
#define PRACTICA2_CONOCIMIENTO_H

#include "Regla.h"
#include <list>
#include <stdio.h>
#include <string.h>

class Conocimiento{
  private:
  public:
    list<Regla *> *reglas;
    Conocimiento();
    ~Conocimiento();
    void addRegla(Regla *regla);
    list<Regla *> *getConjuntoConflicto(list<Literal *> *hechos);
    string toString();
    list<Regla *> *getReglas();
};

#endif // PRACTICA2_CONOCIMIENTO_H
