//
// Grado en Ingeniería Informática. 3º Curso
// Sistemas Inteligentes - Práctica 2
// Daniel Ruiz Villa - 77757166P
//

#include "Regla.h"
#include <algorithm>
#include <fstream>
#include <string>
#include <ctype.h>
using namespace std;

int Regla::contador = 0;

Regla::Regla(){
  condiciones = new list<Literal *>;
  accion = new Literal();
  id = contador++;
  prioridad = 0;
  esUsada = false;
}

Regla::~Regla(){
  list<Literal *>::iterator it = condiciones->begin();
  while(it != condiciones->end()){
    delete(*it);
    ++it;
  }
  delete accion;
  delete condiciones;
}

int Regla::getID(){
  return id;
}

int Regla::getPrioridad(){
  return prioridad;
}

list<Literal *> *Regla::getCondiciones(){
  return condiciones;
};

bool Regla::esReglaUsada(){
  return esUsada;
}

void Regla::setUsada(bool usada){
  this->esUsada = usada;
}

void Regla::setAccion(Literal *literal){
  this->accion = literal;
}

void Regla::nuevaCondicion(Literal *literal){
  condiciones->push_back(literal);
}

bool Regla::validaAntecedentes(list<Literal *> *hechos){

  list<Literal *>::iterator iteradorCondiciones = condiciones->begin();
  list<Literal *>::iterator iteradorHechos;

  string condicionObjeto;
  string condicionOperacion;
  string condicionValor;
  string hechoObjeto;
  string hechoValor;

  bool verificado = true;
  bool validacion;
  bool validacion_condiciones = false;

  while((iteradorCondiciones != condiciones->end()) && (verificado)){ // Recorro las condiciones. Cuando la regla en cuestión
    iteradorHechos = hechos->begin();                              // no cumpla algún antecedente, se detiene. Añadir regla
    validacion = true;                                             // al conjunto conflicto.

    condicionObjeto = (*iteradorCondiciones)->getObjeto();
    condicionValor = (*iteradorCondiciones)->getValor();
    condicionOperacion = (*iteradorCondiciones)->getOperacion();
    hechoObjeto = (*iteradorHechos)->getObjeto();
    hechoValor = (*iteradorHechos)->getValor();


    // Recorro los hechos.
    while((iteradorHechos != hechos->end()) && (!(validacion = condicionObjeto == hechoObjeto))){
      hechoObjeto = (*iteradorHechos)->getObjeto();
      hechoValor = (*iteradorHechos)->getValor();

      if(condicionObjeto == hechoObjeto)
        validacion_condiciones = evaluarCondiciones(condicionValor, condicionOperacion, hechoValor);

      iteradorHechos++;
    }
    verificado = verificado && evaluarCondiciones(condicionValor, condicionOperacion, hechoValor);
    iteradorCondiciones++;
  }
  return verificado;
}

string Regla::toString(){
  stringstream buf;
  list<Literal *>::iterator it;
  it = condiciones->begin();
  int x = 1;
  buf << "R" << id + 1 << ": Si ";        // Inicio de la regla, su número y el inicio de la condición.

  while (it != condiciones->end()){
    buf << (*it)->toString();

    if (x < condiciones->size())          // Si la condición es múltiple.
      buf << " y ";
    else
      buf << " ";

    ++it;
    x++;
  }

  buf << "Entonces ";   // Ponemos el entonces. Hemos llegado a la mitad.

  if (accion != NULL)   // Colocamos la acción en caso de haberla.
    buf << accion->toString();

  return buf.str();
}

bool Regla::evaluarObjetos(string objetoCondicion, string objetoHecho){
  if(objetoCondicion==objetoHecho)
    return true;

  return false;
}

bool Regla::evaluarCondiciones(string valorCondicion, string operacionCondicion,string valorHecho){

  if((isdigit(valorHecho[0])) && (isdigit(valorCondicion[0]))){
    valorHecho = atoi(valorHecho.c_str());
    valorCondicion = atoi(valorCondicion.c_str());
  }

  if(operacionCondicion == "=")
    return(valorHecho == valorCondicion);

  else if(operacionCondicion == ">")
    return(valorHecho > valorCondicion);

  else if(operacionCondicion == ">=")
    return(valorHecho >= valorCondicion);

  else if(operacionCondicion == "<")
    return(valorHecho < valorCondicion);

  else if(operacionCondicion == "<=")
    return(valorHecho <= valorCondicion);

  return false;
}

Literal *Regla::getAccion(){
  return accion;
}

void Regla::establecerPrioridadRegla(int prioridad){
  this->prioridad = prioridad;
}

string Regla::getOperacion(string valor){
  string cadena = valor.substr(0, 2);
  cadena.erase(remove(cadena.begin(), cadena.end(), ' '), cadena.end());    // Elimino los espacios en blanco.
  return cadena;
}

string Regla::getValor(string valor){
  string cadena = valor.substr(2, valor.length());
  cadena.erase(remove(cadena.begin(), cadena.end(), ' '), cadena.end());
  return cadena;
}
