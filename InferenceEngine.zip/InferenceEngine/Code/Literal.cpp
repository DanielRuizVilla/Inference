//
// Grado en Ingeniería Informática. 3º Curso
// Sistemas Inteligentes - Práctica 2
// Daniel Ruiz Villa - 77757166P
//

#include "Literal.h"

Literal::Literal() {
  objeto = " ";
  operacion = " ";
  valor = " ";
}

Literal::Literal(string objeto, string operacion, string valor){
  this->objeto = objeto;
  this->operacion = operacion;
  this->valor = valor;
}

Literal::~Literal(){
}

string Literal::getObjeto(){
    return objeto;
}

string Literal::getOperacion(){
    return operacion;
}

string Literal::getValor(){
    return valor;
}

void Literal::setObjeto(string objeto){
    this->objeto = objeto;
}

void Literal::setOperacion(string operacion){
    this->operacion = operacion;
}

void Literal::setValor(string valor){
    this->valor = valor;
}

string Literal::toString(){
  stringstream buf;
  buf << objeto << " " << operacion << " " << valor;
  return buf.str();
}
