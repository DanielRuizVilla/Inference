//
// Grado en Ingeniería Informática. 3º Curso
// Sistemas Inteligentes - Práctica 2
// Daniel Ruiz Villa - 77757166P
//

#ifndef PRACTICA2_HECHOS_H
#define PRACTICA2_HECHOS_H

#include "Literal.h"
#include <list>

class Hechos {
  private:
      list<Literal *> *hechos;
  public:
      Hechos();
      ~Hechos();
      list<Literal *> *getHechos();
      void nuevoHecho(string obj, string op, string valor);
      string toString();
};

#endif // PRACTICA2_HECHOS_H
