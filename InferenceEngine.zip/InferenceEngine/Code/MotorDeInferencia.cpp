//
// Grado en Ingeniería Informática. 3º Curso
// Sistemas Inteligentes - Práctica 2
// Daniel Ruiz Villa - 77757166P
//

#include "Conocimiento.h"
#include "Hechos.h"
#include "Literal.h"
#include "MotorDeInferencia.h"
#include "Regla.h"
#include <cstring>
#include <fstream>
#include <iostream>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
using namespace std;

MotorDeInferencia::MotorDeInferencia(){
  fichero = new stringstream();
  ficheroSalida1 = new ofstream();
  ficheroSalida2 = new ofstream();

  baseConocimiento = new Conocimiento();
  baseHechos = new Hechos();
  valorPrioridades = new int;
}

MotorDeInferencia::~MotorDeInferencia(){
  delete ficheroSalida1;
  delete ficheroSalida2;

  delete baseConocimiento;
  delete baseHechos;
  delete valorPrioridades;
}

string MotorDeInferencia::funcionSeparadora(string cadena){
  for(int i = 0; i < cadena.length(); i++){
    if(cadena[i] == ',')
      cadena[i] = ' ';
  }
  return cadena;
}

void MotorDeInferencia::getValores(string atributo, string tipo, string valores){
  list<string> valoresAtributo;
  string cadena = valores.substr(1, valores.length()-2);

  cadena = funcionSeparadora(cadena); // Aplicamos la funcion separadora en la cadena.
  istringstream isstream(cadena);

  while(!isstream.eof()){     // Mientras que no acabemos, tratamos los atributos y sus valores.
    string atributos;
    isstream >> atributos;
    if (atributos == "\0")
      valoresAtributo.push_back(atributos);

    else
      valoresAtributo.push_back(atributos);
  }
  mapaNombreValores[atributo] = valoresAtributo;      // Mapa con el nombre de atributo y sus valores.
  mapaAtributoTipo[atributo] = tipo;                  // Mapa con el atributo y su tipo.
}

// Ahora pasamos a las funciones que cargan los tres ficheros que necesitará nuestro
// programa para su ejecución. El fichero de conocimiento, el de configuración y el de hechos.

void MotorDeInferencia::cargarConocimiento(string nombreFichero){
  ifstream fichero;

  string linea;
  string valor;
  string objeto;
  string operacion;

  fichero.open(nombreFichero.c_str(), ifstream::in);

  getline(fichero, linea); // Identificacion del caso que tratamos.
  casoDeEstudio = linea;
  getline(fichero, linea); // Numero de Reglas

  int numeroReglas = atoi(linea.c_str());
  int indiceReglas = 0;

  while (indiceReglas < numeroReglas){
    Regla *regla = new Regla();
    fichero >> linea; // Numero de regla
    fichero >> linea; // Si
    while(linea != "Entonces"){
      Literal *condicion;

      fichero >> linea; // Objeto
      objeto = linea;

      fichero >> linea; // Operacion
      operacion = linea;

      fichero >> linea; // Valor
      valor = linea;

      fichero >> linea;
      condicion = new Literal(objeto, operacion, valor);
      regla->nuevaCondicion(condicion);
    }
    Literal *accion;

    fichero >> linea; // Contiene el Entonces
    objeto = linea;

    fichero >> linea;
    string op = linea;

    fichero >> linea;
    valor = linea;

    accion = new Literal(objeto, op, valor);
    regla->setAccion(accion);                     // Aplicamos la acción a la regla y la añadimos a la lista.
    baseConocimiento->reglas->push_back(regla);

    int prioridad = valorPrioridades[indiceReglas];
    regla->establecerPrioridadRegla(prioridad);
    indiceReglas++;
  }
  fichero.close();
}

void MotorDeInferencia::cargarConfiguracion(string nombreFichero){
  ifstream fichero;

  string linea;
  string metaObjetivo;
  string atributo;
  string tipo;

  int numeroAtributos=0;
  int indice1=0;        // Uso dos indices. Uno para los atributos y otro para leer el número de reglas.
  int indice2=0;
  int valorPrioridad=0;

  fichero.open(nombreFichero.c_str(), ifstream::in);
  getline(fichero, linea); // Atributos.


  fichero >> linea;
  numeroAtributos = atoi(linea.c_str());

  while(indice1 < numeroAtributos){ // Atributos a leer. Diferenciamos Nom y Num.
    fichero >> linea;
    atributo = linea;
    fichero >> linea;
    tipo = linea;

    if(tipo != "NU"){
      fichero >> linea;
      string valores = linea;
      getValores(atributo, tipo, valores);
    }
    else
      getValores(atributo, tipo, "0");

    indice1++;
  }

  fichero >> linea;                             // Objetivo.
  fichero >> linea;                             // Nombre del atributo que queremos alcanzar.
  metaObjetivo = linea;
  meta = new Literal();
  meta->setObjeto(metaObjetivo);

  fichero >> linea;                            // Prioridad - Reglas
  fichero >> linea;                            // Numero reglas.
  numeroReglas = atoi(linea.c_str());

  while(indice2 < numeroReglas){                // Guardamos las prioridades de cada regla.
    fichero >> linea;                           // Numero reglas.
    valorPrioridad = atoi(linea.c_str());
    valorPrioridades[indice2] = valorPrioridad; // Almacenamos la prioridad.
    indice2++;
  }
  fichero.close();
  cout << endl;
}

void MotorDeInferencia::cargarHechos(string nombreFichero){
  ifstream fichero;

  string objeto;
  string operando;
  string valor;
  string linea;

  int numeroHechos = 0;
  int indiceHechos = 0;

  fichero.open(nombreFichero.c_str(), ifstream::in);

  fichero >> linea;
  numeroHechos = atoi(linea.c_str());
  while(indiceHechos < numeroHechos){
    fichero >> linea;
    objeto = linea; // Guardamos el objeto del hecho en cuestión.

    fichero >> linea; // Guardamos el operando del hecho en cuestión.
    operando = linea;

    fichero >> linea; // Guardamos el valor del hecho en cuestión.
    valor = linea;

    baseHechos->nuevoHecho(objeto, operando, valor);
    indiceHechos++;
  }
  cout << " ======= Base de hechos =======" << endl;
  cout << baseHechos->toString() << endl;
  cout << endl;
  fichero.close();
}

list<Regla *> *MotorDeInferencia::match(){
  list<Literal *> *hechos = baseHechos->getHechos();                                 // Obtenemos los hechos.
  list<Regla *> *conjuntoConflicto = baseConocimiento->getConjuntoConflicto(hechos); // Obtenemos el conjunto conflicto.
  return conjuntoConflicto;
}

string MotorDeInferencia::getCasoDeEstudio(){
  return casoDeEstudio;
}

void MotorDeInferencia::nombreSalida1(string ficheroSalida){
  this->salida1 = ficheroSalida;
}

void MotorDeInferencia::nombreSalida2(string ficheroSalida){
  this->salida2 = ficheroSalida;
}

void MotorDeInferencia::start(){
  list<Regla *> *conjuntoConflicto;
  Regla *regla;

  ficheroSalida1->open(salida1.c_str(), ifstream::in);
  ficheroSalida2->open(salida2.c_str(), ifstream::in);

  *ficheroSalida1 << getCasoDeEstudio() << endl;
  *ficheroSalida2 << getCasoDeEstudio() << endl;

  *ficheroSalida1 << endl << "____Base de hechos____" << endl;
  *ficheroSalida1 << endl;
  *ficheroSalida1 << baseHechos->toString() << endl;

  *ficheroSalida1 << "________________________" << endl;
  *ficheroSalida1 << endl << "Las reglas aplicadas han sido: " << endl;
  *ficheroSalida1 << endl;

  *ficheroSalida2 << "________________________" << endl;
  *ficheroSalida2 << endl << "Las reglas aplicadas han sido: " << endl;
  *ficheroSalida2 << endl;

  cout << endl << "La solucion para esta base de hechos esta en los ficheros de salida creados." << endl;
  cout << "Estos ficheros de salida, Salida1.txt y Salida2.txt estan en este mismo directorio." << endl;
  cout << endl;


  do{
    conjuntoConflicto = match();
    if((regla = resolverConflicto(conjuntoConflicto)) != NULL)    // Si no hay reglas en conflicto, la aplicamos.
      aplicarRegla(regla);

    delete conjuntoConflicto;                                     // Borramos fuera el conjunto por si no entra al if.

    if(meta->getOperacion() != " ")
      break;

    else if(regla == NULL){         // Caso de que la regla sea nula, informamos.
      meta->setOperacion("->");
      meta->setValor("Regla no encontrada.");

      *ficheroSalida1 << endl << "Todas las reglas están marcadas. No hay solución." << endl;
      *ficheroSalida2 << endl << "Todas las reglas están marcadas. No hay solución." << endl;
      cout << endl << "Todas las reglas están marcadas. No hay solución." << endl;
    }
  } while (regla != NULL);

  *ficheroSalida2 << endl << "OBJETIVO: " << meta->toString() << endl;    // Comprobamos y evaluamos la base de hechos.
  ficheroSalida1->close();                                                // Cerramos el descriptor de fichero de la salida 1.
  ficheroSalida2->close();                                                // Cerramos el descriptor de fichero de la salida 2.
}

Regla *MotorDeInferencia::resolverConflicto(list<Regla *> *conjuntoConflicto){
  list<Regla *>::iterator it = conjuntoConflicto->begin();
  Regla *regla = (*it);
  bool esVacio = true;

  while(it != conjuntoConflicto->end()){                    // Recorremos el conjunto de conflictos para buscar la regla
    if(esVacio)                                             // que más nos convenga, la mejor. Mayor prioridad con menor ID.
      esVacio = false;

    if((*it)->getPrioridad() == regla->getPrioridad()){       // Buscamos la prioridad.
      if((*it)->getID() < regla->getID())                   // Buscamos la que tenga menor ID.
        regla = (*it);
    }
    it++;
  }

  if(esVacio)          // Si entramos aquí, es que todas las reglas están marcadas y no hay nada que hacer.
    return NULL;

  else                 // En este caso, tras haber hecho el while previo, ya tenemos la mejor regla.
    return regla;
}

void MotorDeInferencia::aplicarRegla(Regla *regla){

  list<Literal *>::iterator iteradorHechos;
  list<Literal *> *condiciones = regla->getCondiciones(); // Condiciones de la regla a aplicar. Las cogemos.
  list<Literal *>::iterator iteradorCondiciones = condiciones->begin(); // Situamos el iterador.

  *ficheroSalida1 << regla->toString() << endl;   // La añadimos al fichero 1.
  *ficheroSalida2 << regla->toString() << endl;   // La añadimos al fichero 2.

  regla->setUsada(true);                  // Cambiamos el estado de la regla, que pasa a estar aplicada (usada).

  if(regla->getAccion()->getObjeto() == meta->getObjeto()){      // Si la regla aplicada es la que teníamos como meta,
    meta->setOperacion(regla->getAccion()->getOperacion());       // aplicamos esa operacion, y establecemos su valor.
    meta->setValor(regla->getAccion()->getValor());
  }
  if(regla != NULL){                                             // Si no, añadimos la nueva regla a la base de hechos.
    baseHechos->nuevoHecho(regla->getAccion()->getObjeto(),regla->getAccion()->getOperacion(),regla->getAccion()->getValor());
  }
}
