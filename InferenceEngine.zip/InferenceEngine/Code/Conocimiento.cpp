//
// Grado en Ingeniería Informática. 3º Curso
// Sistemas Inteligentes - Práctica 2
// Daniel Ruiz Villa - 77757166P 
//

#include "Conocimiento.h"
#include "Regla.h"
#include <algorithm>
using namespace std;

Conocimiento::Conocimiento(){
    reglas = new list<Regla *>();
}

Conocimiento::~Conocimiento(){
    list<Regla *>::iterator it = reglas->begin();
    while(it != reglas->begin()){
      delete(*it);
      ++it;
    }
    delete reglas;
}

list<Regla *> *Conocimiento::getConjuntoConflicto(list<Literal *> *hechos){

    list<Regla *> *getConjuntoConflicto = new list<Regla *>;
    list<Regla *>::iterator it = reglas->begin();

    while(it != reglas->end()){
      if(!((*it)->esReglaUsada()) && ((*it)->validaAntecedentes(hechos))){
        if((*it)->getPrioridad() == 10)
          getConjuntoConflicto->push_front(*it);

        else
          getConjuntoConflicto->push_back(*it);
      }
      it++;
    }
    return getConjuntoConflicto;
}

void Conocimiento::addRegla(Regla *regla){
    reglas->push_back(regla);
}

string Conocimiento::toString(){
    stringstream out;
    list<Regla *>::iterator it;
    it = reglas->begin();

    while (it != reglas->end()){
        cout << (*it)->toString() << endl;
        ++it;
    }
    return out.str();
}

list<Regla *> *Conocimiento::getReglas(){
    return reglas;
}
