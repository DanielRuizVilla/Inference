//
// Grado en Ingeniería Informática. 3º Curso
// Sistemas Inteligentes - Práctica 2
// Daniel Ruiz Villa - 77757166P
//

#include "Hechos.h"
#include <istream>
using namespace std;

Hechos::Hechos(){
    hechos = new list<Literal *>();
}

Hechos::~Hechos(){
    list<Literal *>::iterator it = hechos->begin();
    while(it != hechos->end()){
        delete (*it);
        ++it;
    }
    delete hechos;
}

void Hechos::nuevoHecho(string obj, string op, string valor){
    Literal *literal = new Literal(obj, op, valor);
    hechos->push_back(literal);
}

list<Literal *> *Hechos::getHechos(){
    return hechos;
}

string Hechos::toString(){
    stringstream out;

    list<Literal *>::iterator it;
    it = hechos->begin();

    while(it != hechos->end()){
        out << (*it)->toString() << endl;
        ++it;
    }
    return out.str();
}
