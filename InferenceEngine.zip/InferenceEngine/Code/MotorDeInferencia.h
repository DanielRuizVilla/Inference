//
// Grado en Ingeniería Informática. 3º Curso
// Sistemas Inteligentes - Práctica 2
// Daniel Ruiz Villa - 77757166P
//

#ifndef PRACTICA2_MOTORDEINFERENCIA_H
#define PRACTICA2_MOTORDEINFERENCIA_H

#include "Conocimiento.h"
#include "Hechos.h"
#include "Literal.h"
#include "Regla.h"
#include <list>
#include <map>
#include <sstream>
using namespace std;

class MotorDeInferencia{
  private:
      Conocimiento * baseConocimiento;
      Hechos * baseHechos;
      stringstream *fichero;
      string nombreFicheroSalida1;
      string nombreFicheroSalida2;
      string dominioAplicacion;
      Literal *meta;
      int *valorPrioridades;
      int numeroReglas;
      string casoDeEstudio;

      ofstream *ficheroSalida1;
      ofstream *ficheroSalida2;
      string salida1;
      string salida2;

      map<string, list<string> > mapaNombreValores;
      map<string, string> mapaAtributoTipo;

      list<Regla *> *match();
      Regla *resolverConflicto(list<Regla *> *conjuntoConflicto);
      void aplicarRegla(Regla *regla);

    public:
      MotorDeInferencia();
      ~MotorDeInferencia();

      void cargarConocimiento(string fileName);
      void cargarConfiguracion(string fileName);
      void cargarHechos(string fileName);

      void start();
      void getValores(string atributo, string tipo, string valores);
      bool esNumero(string cadena);
      void nombreSalida1(string logName);
      void nombreSalida2(string logName);

      string getCasoDeEstudio();
      string funcionSeparadora(string cadena);
};

#endif // PRACTICA2_MOTORDEINFERENCIA_H
