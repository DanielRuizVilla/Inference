//
// Grado en Ingeniería Informática. 3º Curso
// Sistemas Inteligentes - Práctica 2
// Daniel Ruiz Villa - 77757166P
//

#include "MotorDeInferencia.h"
#include <cstring>
#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>

using namespace std;

int main(int argc, char *argv[]){

  MotorDeInferencia *motorinferencia = new MotorDeInferencia();  // Motor de inferencia.
  string Conocimiento = argv[1];    // Parámetro 1, la base de conocimiento.
  string Configuracion = argv[2];   // Parámetro 2, el fichero de configuración.
  string Hechos = argv[3];          // Parámetro 3, la base de hechos del caso en concreto.

  motorinferencia->nombreSalida1("Salida1.txt");  // Salida1
  motorinferencia->nombreSalida2("Salida2.txt");  // Salida2

  ofstream fs("Salida1.txt");
  ofstream fs1("Salida2.txt");

  motorinferencia->cargarConocimiento(Conocimiento);      // Cargamos la base de conocimiento.
  motorinferencia->cargarConfiguracion(Configuracion);    // Cargamos la configuración.
  motorinferencia->cargarHechos(Hechos);                  // Cargamos la base de hechos.
  motorinferencia->start();                                 // Arrancamos el programa.

  fs.close();
}
