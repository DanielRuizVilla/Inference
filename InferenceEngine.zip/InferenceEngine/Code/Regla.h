//
// Grado en Ingeniería Informática. 3º Curso
// Sistemas Inteligentes - Práctica 2
// Daniel Ruiz Villa - 77757166P
//

#ifndef PRACTICA2_REGLA_H
#define PRACTICA2_REGLA_H

#include "Literal.h"
#include <iostream>
#include <list>
#include <sstream>
#include <string>
#include <ctype.h>

class Regla {
private:
  static int contador;
  int id;
  int prioridad;
  list<Literal *> *condiciones;
  Literal *accion;

public:
  Regla();
  ~Regla();
  int getID();
  int getPrioridad();
  list<Literal *> *getCondiciones();
  void establecerPrioridadRegla(int prioridad);
  void setUsada(bool usada);
  void nuevaCondicion(Literal *literal);
  void setAccion(Literal *literal);
  Literal *getAccion();
  string getOperacion(string valor);
  string getValor(string valor);
  string toString();
  bool esUsada;
  bool esReglaUsada();
  bool validaAntecedentes(list<Literal *> *hechos);
  bool evaluarValores(list<Literal *> *hechos);
  bool evaluarObjetos(string objetoCondicion, string objetoHecho);
  bool evaluarCondiciones(string valorCondicion, string operacionCondicion, string valorHecho);
  bool esNumero(string cadena);
};

#endif // PRACTICA2_REGLA_H
