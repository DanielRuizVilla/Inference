//
// Grado en Ingeniería Informática. 3º Curso
// Sistemas Inteligentes - Práctica 2
// Daniel Ruiz Villa - 77757166P
//

#ifndef PRACTICA2_LITERAL_H
#define PRACTICA2_LITERAL_H

#include <iostream>
#include <list>
#include <sstream>
#include <string>
using namespace std;

class Literal{
  private:
      string objeto;
      string operacion;
      string valor;
  public:
      Literal();
      Literal(string objeto, string operacion, string valor);
      ~Literal();
      string getObjeto();
      string getOperacion();
      string getValor();
      void setObjeto(string objeto);
      void setOperacion(string operacion);
      void setValor(string valor);
      string toString();
};

#endif // PRACTICA2_LITERAL_H
